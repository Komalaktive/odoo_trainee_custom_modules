# -*- coding: utf-8 -*-
from . import student
from . import teacher
