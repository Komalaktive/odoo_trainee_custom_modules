from odoo import api, fields, models


class Practical(models.Model):
    _name = "hr.referral.application"
    _description = "Practical Task"

    name = fields.Char(string="Name")
    email = fields.Char(string="Email")
    state = fields.Selection(
        string="Status",
        default="draft",
        readonly=True,
        copy=False,
        selection=[("draft", "Draft"), ("approved", "Approved"), ("cancel", "Cancel")],
    )

    currency_id = fields.Many2one("res.currency", string="Currency")
    reference_name_id = fields.Many2one("hr.employee", string="Referral Name")
    degree_id = fields.Many2one("hr.recruitment.degree", string="Degree")
    dept_id = fields.Many2one("hr.job", string="Department")
    ex_salary = fields.Monetary(string="Expected Salary", store=True)
    summary = fields.Text(string="Summary")
    joining_date = fields.Date(string="Expected joining Date")

    def action_approved(self):
        for rec in self:
            rec.write({"state": "approved"})

    def action_draft(self):
        self.write = "draft"

    def action_cancel(self):
        self.write = "cancel"
