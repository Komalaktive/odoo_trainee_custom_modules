Create Employee
---------
this document is used to create Employees and to fill Registration form.