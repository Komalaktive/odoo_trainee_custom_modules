{
    "name": "tracking Order",
    "summary": """
        Practical Task""",
    "description": """
        Task
    """,
    "author": "Komal Jimudiya",
    "website": "http://www.yourcompany.com",
    "category": "Business",
    "version": "14.0.1.0.0",
    "depends": ["base", "sale_management"],
    "data": [
        "security/ir.model.access.csv",
        "views/track_order_views.xml",
    ],
    "installable": True,
    "auto_install": False,
    "application": True,
    "sequence": 1,
}
