
from . import inherit_sequence


