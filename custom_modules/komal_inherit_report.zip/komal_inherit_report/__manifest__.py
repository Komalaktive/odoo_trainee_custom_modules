# -*- coding: utf-8 -*-
{
    "name": "Inherit Report",
    "summary": """
        Task of inherit report""",
    "description": """
        Inherit report
    """,
    "author": "Komal Jimudiya",
    "website": "http://www.yourcompany.com",
    "category": "Business",
    "version": "14.0.1.0.0",
    "depends": ["base","stock","sale_management"],
    "data": ["report/sale_report_inherit.xml"],
   
}
