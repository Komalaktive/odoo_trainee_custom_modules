
from odoo import fields, models


class InheritReport(models.Model):
    _name = "inherit.report"