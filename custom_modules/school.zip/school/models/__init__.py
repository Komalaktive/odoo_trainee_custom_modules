# -*- coding: utf-8 -*-
from . import student
from . import teacher
from . import res_config_setting
from . import res_partner
from . import res_partner_button_inherit
