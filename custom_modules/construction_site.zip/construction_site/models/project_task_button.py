from odoo import models


class ProjectOrder(models.Model):
    _inherit = "project.task"
